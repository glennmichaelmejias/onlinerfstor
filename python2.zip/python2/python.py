import openpyxl
import sys
from openpyxl.drawing.image import Image

theform = sys.argv[1]

if(theform=="RFS"):

	xfile = openpyxl.load_workbook('printing\RFS Form.xlsx')

	number=sys.argv[2]
	companyname=sys.argv[3]
	businessunit=sys.argv[4]
	address=sys.argv[5]
	contactno=sys.argv[6]
	date=sys.argv[7]

	f = open(sys.argv[8], 'r')
	details=f.read()

	requestedby=sys.argv[9]
	approvedby=sys.argv[10]
	reviewedby=sys.argv[11]
	implementedby=sys.argv[12]
	idnumber=sys.argv[13]
	requestmode=sys.argv[14]
	requesttype=sys.argv[15]
	purpose=sys.argv[16]

	addresses = {
		'number':'K2',
		'companyname':'C5',
		'businessunit':'C6',
		'address':'C7',
		'contactno':'I5',
		'date':'I6',
		'details':'A10',
		'requestedby':'B18',
		'approvedby':'H18',
		'reviewedby':'B23',
		'implementedby':'H23',
		'requestmode':'C8',
		'requesttype':'I8',
		'purpose':'C15'
	}

	sheet = xfile.get_sheet_by_name('Sheet1')

	img = Image('alturaslogo.png')
	img.drawing.width=102.72
	img.drawing.height=33.6
	sheet.add_image(img, 'A2')

	sheet[addresses['number']]=number
	sheet[addresses['companyname']]=companyname
	sheet[addresses['businessunit']]=businessunit
	sheet[addresses['address']]=address

	sheet[addresses['contactno']]=contactno
	sheet[addresses['date']]=date
	sheet[addresses['details']]=details
	sheet[addresses['requestedby']]=requestedby
	sheet[addresses['approvedby']]=approvedby

	sheet[addresses['reviewedby']]=reviewedby
	sheet[addresses['implementedby']]=implementedby

	sheet[addresses['requestmode']]=requestmode
	sheet[addresses['requesttype']]=requesttype
	sheet[addresses['purpose']]=purpose

	xfile.save("printing\\tempxlsx\\"+idnumber+'.xlsx')

elif(theform=="TOR"):

	xfile = openpyxl.load_workbook('printing\TOR Form.xlsx')
	


	imagefile=sys.argv[2]#
	businessunit=sys.argv[3]#"Delivery & Trucking"
	idnumber=sys.argv[4]
	number=sys.argv[5]
	purpose=sys.argv[6]
	adjustment=sys.argv[7]
	authoritytoreprint=sys.argv[8]
	authoritytocancel=sys.argv[9]
	#details=sys.argv[10]

	f = open(sys.argv[10], 'r')
	details=f.read()


	requestedby=sys.argv[11]
	verifiedby=sys.argv[12]
	adjustedby=sys.argv[13]
	approvedby=sys.argv[14]

	
	#imagefile="printing/logomarcelafarms.png"#sys.argv[2]#"logodeliveryandtrucking.png" 
	# businessunit="asdf"#sys.argv[3]#"Delivery & Trucking"
	# idnumber="asdf"#sys.argv[4]
	# number="asdf"#sys.argv[5]
	# purpose="asdf"#sys.argv[6]
	# adjustment="asdf"#sys.argv[7]
	# authoritytoreprint="asdf"#sys.argv[8]
	# authoritytocancel="asdf"#sys.argv[9]
	# details="asdf"#sys.argv[10]
	# requestedby="asdf"#sys.argv[11]
	# verifiedby="asdf"#sys.argv[12]
	# adjustedby="asdf"#sys.argv[13]
	# approvedby="asdf"#sys.argv[14]
	

	addresses={
		'logo':'H1',
		'businessunit':'E6',
		'number':'K6',
		'purpose':'E7',

		'adjustment':'C9',
		'authoritytoreprint':'F9',
		'authoritytocancel':'I9',
		'details':'D12',
		'requestedby':'B17',
		'verifiedby':'I17',
		'adjustedby':'B22',
		'approvedby':'I22'
	}

	sheet = xfile.get_sheet_by_name('Sheet1')

	img = Image(imagefile)
	img.drawing.width=64.32
	img.drawing.height=45.12
	img.drawing.left=100
	sheet.add_image(img, addresses['logo'])

	sheet[addresses['number']]=number
	sheet[addresses['businessunit']]=businessunit
	sheet[addresses['purpose']]=purpose

	sheet[addresses['adjustment']]=adjustment
	sheet[addresses['authoritytoreprint']]=authoritytoreprint
	sheet[addresses['authoritytocancel']]=authoritytocancel
	sheet[addresses['details']]=details
	sheet[addresses['verifiedby']]=verifiedby

	sheet[addresses['adjustedby']]=adjustedby
	sheet[addresses['approvedby']]=approvedby
	sheet[addresses['requestedby']]=requestedby

	xfile.save("printing\\tempxlsx\\"+idnumber+'.xlsx')

elif(theform=="RFSsoftsys"):
	xfile = openpyxl.load_workbook('printing\RFS Form(systemsoftware).xlsx')

	number=sys.argv[2]
	companyname=sys.argv[3]
	businessunit=sys.argv[4]
	address=sys.argv[5]
	contactno=sys.argv[6]
	date=sys.argv[7]

	f = open(sys.argv[8], 'r')
	details=f.read()

	requestedby=sys.argv[9]
	approvedby=sys.argv[10]
	implementedby=sys.argv[11]
	idnumber=sys.argv[12]
	requestmode=sys.argv[13]
	requesttype=sys.argv[14]
	purpose=sys.argv[15]
	systemtype=sys.argv[16]
	remarks=sys.argv[17]

	addresses = {
		'number':'K2',
		'companyname':'C5',
		'businessunit':'C6',
		'address':'C7',
		'contactno':'I5',
		'date':'I6',
		'details':'A10',
		'requestedby':'B18',
		'approvedby':'D24',
		'implementedby':'H18',
		'requestmode':'I8',
		'requesttype':'I7',
		'purpose':'C15',
		'systemtype':'C8',
		'remarks':'A12'
	}

	sheet = xfile.get_sheet_by_name('Sheet1')

	img = Image('alturaslogo.png')
	img.drawing.width=102.72
	img.drawing.height=33.6
	sheet.add_image(img, 'A2')

	sheet[addresses['number']]=number
	sheet[addresses['companyname']]=companyname
	sheet[addresses['businessunit']]=businessunit
	sheet[addresses['address']]=address

	sheet[addresses['contactno']]=contactno
	sheet[addresses['date']]=date
	sheet[addresses['details']]=details
	sheet[addresses['requestedby']]=requestedby
	sheet[addresses['approvedby']]=approvedby

	sheet[addresses['implementedby']]=implementedby

	sheet[addresses['requestmode']]=requestmode
	sheet[addresses['requesttype']]=requesttype
	sheet[addresses['purpose']]=purpose

	sheet[addresses['systemtype']]=systemtype
	sheet[addresses['remarks']]=remarks

	xfile.save("printing\\tempxlsx\\"+idnumber+'.xlsx')